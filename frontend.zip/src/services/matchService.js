import axios from "axios";

const API_URL = "http://localhost:5000/api/matches";

export const getMatches = async () => {
  return axios.get(`${API_URL}/matches`, {
    headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
  });
};
